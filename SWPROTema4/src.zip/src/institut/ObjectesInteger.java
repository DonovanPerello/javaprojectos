package institut;
//Afegeix un identificador numèric a cada Mòdul. Segurament necessitis una variable i un mètode de classe per portar el registre.
public class ObjectesInteger {

}
